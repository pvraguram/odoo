{
    'name': 'Service Job Tracker',
    'version': '1.0',
    'category': 'Services',
    'summary': 'Track workshop service orders end to end',
    'depends': ['base', 'mail'],
    'data': [
        'security/ir.model.access.csv',
        'views/service_order_views.xml',
    ],
    'installable': True,
    'application': True,
}