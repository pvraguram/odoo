from odoo import models, fields

class ServiceOrder(models.Model):
    _name = 'service_order'
    _description = 'Service Order'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Order Reference', required=True, tracking=True)
    customer_id = fields.Many2one('res.partner', string='Customer', required=True)
    date_order = fields.Date(string='Order Date', default=fields.Date.today)
    notes = fields.Text(string='Notes')